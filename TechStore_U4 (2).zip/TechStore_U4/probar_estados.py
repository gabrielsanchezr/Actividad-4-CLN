
from cargar_csv import load_fixture
from app.domain import InvalidOrderTransition

orders = load_fixture()
order = orders["O013"]

print("Estado inicial:", order.status.value)
print("Eventos iniciales:", len(order.events))

# Primera confirmación: debe funcionar.
order.confirm()

print("Estado después de confirmar:", order.status.value)
print("Eventos:", [event.name for event in order.events])

# Segunda confirmación: debe rechazarse.
try:
    order.confirm()
except InvalidOrderTransition as exc:
    print("Segunda confirmación rechazada:", exc)

print("Estado final:", order.status.value)
print("Total de eventos:", len(order.events))
