
from cargar_csv import load_fixture
from app.domain import InvalidOrderTransition, InvalidOrderData

orders = load_fixture()
order = orders["O013"]

print("Estado inicial:", order.status.value)

# Confirmar el pedido
order.confirm()
print("Después de confirmar:", order.status.value)

# Intentar enviar sin guía
try:
    order.ship("")
except InvalidOrderData as exc:
    print("Envío sin guía rechazado:", exc)

print("Estado después del intento fallido:", order.status.value)
print("Eventos registrados:", [event.name for event in order.events])

# Enviar con una guía válida
order.ship("GUIA-12345")
print("Después de enviar:", order.status.value)
print("Eventos registrados:", [event.name for event in order.events])

# Entregar el pedido
order.deliver()
print("Después de entregar:", order.status.value)
print("Eventos finales:", [event.name for event in order.events])
