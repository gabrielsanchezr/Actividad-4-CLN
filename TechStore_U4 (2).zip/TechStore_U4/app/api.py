
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from cargar_csv import load_fixture
from app.domain import (
    InvalidOrderData,
    InvalidOrderTransition,
    OrderStatus,
)

app = FastAPI(
    title="TechStore API",
    description="API para administrar pedidos y reglas de negocio",
    version="1.0.0",
)

# Repositorio en memoria: los cambios no persisten al reiniciar.
orders = load_fixture()


class ShippingRequest(BaseModel):
    tracking_number: str


class CancellationRequest(BaseModel):
    reason: str


def get_order_or_404(order_id: str):
    order = orders.get(order_id)

    if order is None:
        raise HTTPException(
            status_code=404,
            detail="Pedido no encontrado",
        )

    return order


def serialize_order(order):
    return {
        "id": order.id,
        "customer_id": order.customer.id,
        "status": order.status.value,
        "units": order.units,
        "total_mxn": str(order.total.amount),
        "has_promotion": order.has_promotion,
        "items": [
            {
                "sku": item.sku,
                "quantity": item.quantity,
                "unit_price_mxn": str(item.unit_price.amount),
                "subtotal_mxn": str(item.subtotal.amount),
            }
            for item in order.items
        ],
        "events": [
            {
                "name": event.name,
                "order_id": event.order_id,
                "occurred_at": event.occurred_at.isoformat(),
            }
            for event in order.events
        ],
    }


@app.get("/")
def home():
    return {"message": "TechStore API funcionando"}


@app.get("/orders")
def list_orders():
    return [serialize_order(order) for order in orders.values()]


@app.get("/orders/{order_id}")
def get_order(order_id: str):
    order = get_order_or_404(order_id)
    return serialize_order(order)


@app.post("/orders/{order_id}/confirm")
def confirm_order(order_id: str):
    order = get_order_or_404(order_id)

    try:
        order.confirm()
    except InvalidOrderTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except InvalidOrderData as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    return serialize_order(order)


@app.post("/orders/{order_id}/ship")
def ship_order(order_id: str, request: ShippingRequest):
    order = get_order_or_404(order_id)

    try:
        order.ship(request.tracking_number)
    except InvalidOrderTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except InvalidOrderData as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    return serialize_order(order)


@app.post("/orders/{order_id}/cancel")
def cancel_order(order_id: str, request: CancellationRequest):
    order = get_order_or_404(order_id)

    try:
        order.cancel(request.reason)
    except InvalidOrderTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except InvalidOrderData as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    return serialize_order(order)


@app.post("/orders/{order_id}/deliver")
def deliver_order(order_id: str):
    order = get_order_or_404(order_id)

    try:
        order.deliver()
    except InvalidOrderTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except InvalidOrderData as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    return serialize_order(order)


@app.post("/orders/{order_id}/return")
def return_order(order_id: str):
    order = get_order_or_404(order_id)

    try:
        order.return_order()
    except InvalidOrderTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except InvalidOrderData as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    return serialize_order(order)
