
from dataclasses import dataclass, field
from decimal import Decimal
from datetime import datetime, timezone
from enum import Enum


# Excepciones del dominio
class DomainException(Exception):
    pass


class InvalidOrderData(DomainException):
    pass


class InvalidOrderTransition(DomainException):
    pass


class OrderItemLimitExceeded(DomainException):
    pass


# Objeto de valor para representar dinero
@dataclass(frozen=True)
class Money:
    amount: Decimal
    currency: str = "MXN"

    def __post_init__(self):
        try:
            value = Decimal(str(self.amount))
        except Exception as exc:
            raise InvalidOrderData("Monto inválido") from exc

        if not value.is_finite() or value < Decimal("0"):
            raise InvalidOrderData("El monto debe ser válido y no negativo")

        object.__setattr__(self, "amount", value)

    def add(self, other):
        if self.currency != other.currency:
            raise InvalidOrderData("No se pueden sumar monedas diferentes")

        return Money(self.amount + other.amount, self.currency)

    def multiply(self, quantity):
        if not isinstance(quantity, int) or isinstance(quantity, bool):
            raise InvalidOrderData("La cantidad debe ser un entero")

        if quantity < 0:
            raise InvalidOrderData("La cantidad no puede ser negativa")

        return Money(self.amount * quantity, self.currency)


# Cliente
@dataclass(frozen=True)
class Customer:
    id: str
    is_vip: bool = False
    active: bool = True


# Artículo de un pedido
@dataclass(frozen=True)
class OrderItem:
    sku: str
    quantity: int
    unit_price: Money

    def __post_init__(self):
        if not self.sku.strip():
            raise InvalidOrderData("El SKU no puede estar vacío")

        if (
            not isinstance(self.quantity, int)
            or isinstance(self.quantity, bool)
            or self.quantity <= 0
        ):
            raise InvalidOrderData("La cantidad debe ser un entero positivo")

        if self.unit_price.currency != "MXN":
            raise InvalidOrderData("Solo se permiten precios en MXN")

    @property
    def subtotal(self):
        return Money(
            self.unit_price.amount * self.quantity,
            self.unit_price.currency
        )


# Estados permitidos
class OrderStatus(str, Enum):
    DRAFT = "DRAFT"
    CONFIRMED = "CONFIRMED"
    SHIPPED = "SHIPPED"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"
    RETURNED = "RETURNED"


# Evento del dominio
@dataclass(frozen=True)
class DomainEvent:
    name: str
    order_id: str
    occurred_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )


# Pedido
@dataclass
class Order:
    customer: Customer
    id: str
    has_promotion: bool = False
    status: OrderStatus = OrderStatus.DRAFT
    items: list = field(default_factory=list)
    events: list = field(default_factory=list)

    @property
    def units(self):
        return sum(item.quantity for item in self.items)

    @property
    def total(self):
        amount = sum(
            (item.subtotal.amount for item in self.items),
            Decimal("0")
        )
        return Money(amount)

    def add_item(self, item):
        if self.status != OrderStatus.DRAFT:
            raise InvalidOrderTransition(
                "Solo se pueden agregar artículos a pedidos DRAFT"
            )

        if self.units + item.quantity > 20:
            raise OrderItemLimitExceeded(
                "Un pedido no puede superar las 20 unidades"
            )

        self.items.append(item)

    def confirm(self):
        if self.status != OrderStatus.DRAFT:
            raise InvalidOrderTransition(
                "Solo se pueden confirmar pedidos DRAFT"
            )

        if not self.items:
            raise InvalidOrderData(
                "No se puede confirmar un pedido sin artículos"
            )

        if not self.customer.active:
            raise InvalidOrderData(
                "No se puede confirmar un pedido de un cliente inactivo"
            )

        self.status = OrderStatus.CONFIRMED
        self.events.append(DomainEvent("OrderConfirmed", self.id))

    def ship(self, tracking_number):
        if self.status != OrderStatus.CONFIRMED:
            raise InvalidOrderTransition(
                "Solo se pueden enviar pedidos CONFIRMED"
            )

        if not isinstance(tracking_number, str) or not tracking_number.strip():
            raise InvalidOrderData(
                "Se requiere un número de guía válido"
            )

        self.status = OrderStatus.SHIPPED
        self.events.append(DomainEvent("OrderShipped", self.id))

    def cancel(self, reason):
        if self.status != OrderStatus.CONFIRMED:
            raise InvalidOrderTransition(
                "Solo se pueden cancelar pedidos CONFIRMED"
            )

        if not isinstance(reason, str) or not reason.strip():
            raise InvalidOrderData(
                "Se requiere un motivo de cancelación"
            )

        self.status = OrderStatus.CANCELLED
        self.events.append(DomainEvent("OrderCancelled", self.id))

    def deliver(self):
        if self.status != OrderStatus.SHIPPED:
            raise InvalidOrderTransition(
                "Solo se pueden entregar pedidos SHIPPED"
            )

        self.status = OrderStatus.DELIVERED
        self.events.append(DomainEvent("OrderDelivered", self.id))

    def return_order(self):
        if self.status != OrderStatus.SHIPPED:
            raise InvalidOrderTransition(
                "Solo se pueden devolver pedidos SHIPPED"
            )

        self.status = OrderStatus.RETURNED
        self.events.append(DomainEvent("OrderReturned", self.id))
