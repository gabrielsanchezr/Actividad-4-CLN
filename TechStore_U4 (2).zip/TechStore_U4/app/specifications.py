
from dataclasses import dataclass
from decimal import Decimal


class Specification:
    """Clase base para evaluar reglas de negocio."""

    def is_satisfied_by(self, order) -> bool:
        raise NotImplementedError

    def __and__(self, other):
        return AndSpecification(self, other)

    def __or__(self, other):
        return OrSpecification(self, other)

    def __invert__(self):
        return NotSpecification(self)


@dataclass(frozen=True)
class AndSpecification(Specification):
    first: Specification
    second: Specification

    def is_satisfied_by(self, order) -> bool:
        return (
            self.first.is_satisfied_by(order)
            and self.second.is_satisfied_by(order)
        )


@dataclass(frozen=True)
class OrSpecification(Specification):
    first: Specification
    second: Specification

    def is_satisfied_by(self, order) -> bool:
        return (
            self.first.is_satisfied_by(order)
            or self.second.is_satisfied_by(order)
        )


@dataclass(frozen=True)
class NotSpecification(Specification):
    specification: Specification

    def is_satisfied_by(self, order) -> bool:
        return not self.specification.is_satisfied_by(order)


class IsVipSpecification(Specification):
    def is_satisfied_by(self, order) -> bool:
        return order.customer.is_vip


class MinimumTotalSpecification(Specification):
    def __init__(self, minimum):
        self.minimum = Decimal(str(minimum))

    def is_satisfied_by(self, order) -> bool:
        return order.total.amount > self.minimum


class MinimumUnitsSpecification(Specification):
    def __init__(self, minimum):
        self.minimum = minimum

    def is_satisfied_by(self, order) -> bool:
        return order.units >= self.minimum


class HasPromotionSpecification(Specification):
    def is_satisfied_by(self, order) -> bool:
        return order.has_promotion


class TenPercentDiscountSpecification(Specification):
    def is_satisfied_by(self, order) -> bool:
        return (
            IsVipSpecification().is_satisfied_by(order)
            and MinimumTotalSpecification(500).is_satisfied_by(order)
            and MinimumUnitsSpecification(4).is_satisfied_by(order)
            and NotSpecification(
                HasPromotionSpecification()
            ).is_satisfied_by(order)
        )


class FivePercentDiscountSpecification(Specification):
    def is_satisfied_by(self, order) -> bool:
        return (
            MinimumTotalSpecification(5000).is_satisfied_by(order)
            and NotSpecification(
                HasPromotionSpecification()
            ).is_satisfied_by(order)
        )


def get_discount_rate(order):
    """Devuelve la tasa de descuento que corresponde al pedido."""
    if TenPercentDiscountSpecification().is_satisfied_by(order):
        return Decimal("0.10")

    if FivePercentDiscountSpecification().is_satisfied_by(order):
        return Decimal("0.05")

    return Decimal("0.00")


def calculate_discount(order):
    """Calcula el importe del descuento sin modificar el pedido."""
    rate = get_discount_rate(order)
    return order.total.amount * rate


def calculate_final_total(order):
    """Devuelve el total después del descuento, sin modificar el pedido."""
    return order.total.amount - calculate_discount(order)
