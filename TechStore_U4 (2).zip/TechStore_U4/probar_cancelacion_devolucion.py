
from cargar_csv import load_fixture
from app.domain import InvalidOrderTransition, InvalidOrderData

orders = load_fixture()

# PRUEBA 1: Cancelación
pedido_cancelar = orders["O013"]

pedido_cancelar.confirm()
pedido_cancelar.cancel("El cliente solicitó cancelar")

print("=== CANCELACIÓN ===")
print("Estado:", pedido_cancelar.status.value)
print("Eventos:", [e.name for e in pedido_cancelar.events])

# PRUEBA 2: Devolución
pedido_devolver = orders["O014"]

pedido_devolver.confirm()
pedido_devolver.ship("GUIA-DEV-001")
pedido_devolver.return_order()

print("\n=== DEVOLUCIÓN ===")
print("Estado:", pedido_devolver.status.value)
print("Eventos:", [e.name for e in pedido_devolver.events])

# PRUEBA 3: Intentar devolver un pedido DRAFT
pedido_invalido = orders["O015"]

print("\n=== TRANSICIÓN INVÁLIDA ===")

try:
    pedido_invalido.return_order()
except InvalidOrderTransition as exc:
    print("Devolución rechazada:", exc)

print("Estado:", pedido_invalido.status.value)
print("Eventos:", [e.name for e in pedido_invalido.events])
