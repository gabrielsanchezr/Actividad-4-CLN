
import pytest
from decimal import Decimal
from cargar_csv import load_fixture
from app.domain import (
    Money,
    OrderStatus,
    InvalidOrderTransition,
    InvalidOrderData,
    OrderItemLimitExceeded,
)


def test_se_cargan_los_16_pedidos():
    orders = load_fixture()

    assert len(orders) == 16


def test_todos_los_pedidos_inician_en_draft():
    orders = load_fixture()

    for order in orders.values():
        assert order.status == OrderStatus.DRAFT


def test_pedido_o001_tiene_total_correcto():
    orders = load_fixture()
    order = orders["O001"]

    assert order.units == 4
    assert order.total.amount == Money("2100").amount


def test_money_rechaza_importes_negativos():
    with pytest.raises(InvalidOrderData):
        Money("-10")


def test_no_se_puede_confirmar_dos_veces():
    orders = load_fixture()
    order = orders["O013"]

    order.confirm()
    eventos_antes = len(order.events)

    with pytest.raises(InvalidOrderTransition):
        order.confirm()

    assert order.status == OrderStatus.CONFIRMED
    assert len(order.events) == eventos_antes


def test_no_se_puede_enviar_sin_guia():
    orders = load_fixture()
    order = orders["O013"]
    order.confirm()

    eventos_antes = len(order.events)

    with pytest.raises(InvalidOrderData):
        order.ship("")

    assert order.status == OrderStatus.CONFIRMED
    assert len(order.events) == eventos_antes


def test_pedido_no_puede_superar_20_unidades():
    orders = load_fixture()
    order = orders["O008"]

    assert order.units == 20

    item = OrderItemLimitExceeded

    # El pedido ya tiene 20 unidades; agregar otra debe fallar.
    from app.domain import OrderItem

    articulo = OrderItem(
        sku="PRUEBA",
        quantity=1,
        unit_price=Money("10")
    )

    with pytest.raises(OrderItemLimitExceeded):
        order.add_item(articulo)


from app.specifications import (
    get_discount_rate,
    calculate_discount,
    calculate_final_total,
)


def test_pedido_o001_recibe_descuento_del_10_por_ciento():
    order = load_fixture()["O001"]

    assert get_discount_rate(order) == Decimal("0.10")
    assert calculate_discount(order) == Decimal("210.00")
    assert calculate_final_total(order) == Decimal("1890.00")


def test_pedido_o006_recibe_descuento_del_5_por_ciento():
    order = load_fixture()["O006"]

    assert get_discount_rate(order) == Decimal("0.05")
    assert calculate_discount(order) == Decimal("900.00")
    assert calculate_final_total(order) == Decimal("17100.00")


def test_promocion_activa_impide_descuentos():
    order = load_fixture()["O001"]
    order.has_promotion = True

    assert get_discount_rate(order) == Decimal("0.00")


def test_pedido_sin_condiciones_no_recibe_descuento():
    order = load_fixture()["O002"]

    assert get_discount_rate(order) == Decimal("0.00")
