
import pytest

from cargar_csv import load_fixture
from app.domain import (
    Money,
    OrderItem,
    OrderStatus,
    InvalidOrderData,
    InvalidOrderTransition,
    OrderItemLimitExceeded,
)
from app.specifications import get_discount_rate


def test_E01_descuento_10_por_ciento():
    order = load_fixture()["O001"]
    assert get_discount_rate(order) == Money("0.10").amount


def test_E02_sin_descuento():
    order = load_fixture()["O002"]
    assert get_discount_rate(order) == Money("0").amount


def test_E03_cliente_inactivo_no_puede_confirmar():
    order = load_fixture()["O003"]

    with pytest.raises(InvalidOrderData):
        order.confirm()

    assert order.status == OrderStatus.DRAFT
    assert len(order.events) == 0


def test_E04_promocion_activa_bloquea_descuento():
    order = load_fixture()["O005"]
    assert get_discount_rate(order) == Money("0").amount


def test_E05_descuento_5_por_ciento():
    order = load_fixture()["O006"]
    assert get_discount_rate(order) == Money("0.05").amount


def test_E06_pedido_vacio_no_se_confirma():
    order = load_fixture()["O007"]

    with pytest.raises(InvalidOrderData):
        order.confirm()

    assert order.status == OrderStatus.DRAFT
    assert len(order.events) == 0


def test_E07_se_permiten_20_unidades():
    order = load_fixture()["O008"]

    assert order.units == 20
    order.confirm()

    assert order.status == OrderStatus.CONFIRMED


def test_E08_no_se_permiten_mas_de_20_unidades():
    order = load_fixture()["O009"]

    assert order.units == 19

    extra_item = OrderItem(
        sku="SKU003",
        quantity=2,
        unit_price=Money("10")
    )

    with pytest.raises(OrderItemLimitExceeded):
        order.add_item(extra_item)

    assert order.units == 19


def test_E09_total_de_500_no_supera_el_umbral():
    order = load_fixture()["O010"]

    assert order.total.amount == Money("500").amount
    assert get_discount_rate(order) == Money("0").amount


def test_E10_tres_unidades_no_cumplen_minimo():
    order = load_fixture()["O011"]

    assert order.units == 3
    assert get_discount_rate(order) == Money("0").amount


def test_E11_no_se_envia_sin_guia():
    order = load_fixture()["O012"]
    order.confirm()
    eventos_antes = len(order.events)

    with pytest.raises(InvalidOrderData):
        order.ship("")

    assert order.status == OrderStatus.CONFIRMED
    assert len(order.events) == eventos_antes


def test_E12_no_se_confirma_dos_veces():
    order = load_fixture()["O013"]
    order.confirm()
    eventos_antes = len(order.events)

    with pytest.raises(InvalidOrderTransition):
        order.confirm()

    assert order.status == OrderStatus.CONFIRMED
    assert len(order.events) == eventos_antes


def test_E13_no_se_cancela_desde_shipped():
    order = load_fixture()["O014"]
    order.confirm()
    order.ship("GUIA-014")

    eventos_antes = len(order.events)

    with pytest.raises(InvalidOrderTransition):
        order.cancel("Cancelación de prueba")

    assert order.status == OrderStatus.SHIPPED
    assert len(order.events) == eventos_antes


def test_E14_pedido_termina_en_returned():
    order = load_fixture()["O015"]
    order.confirm()
    order.ship("GUIA-015")
    order.return_order()

    assert order.status == OrderStatus.RETURNED
    assert [e.name for e in order.events] == [
        "OrderConfirmed",
        "OrderShipped",
        "OrderReturned",
    ]


def test_E15_pedido_termina_en_delivered():
    order = load_fixture()["O016"]
    order.confirm()
    order.ship("GUIA-016")
    order.deliver()

    assert order.status == OrderStatus.DELIVERED
    assert [e.name for e in order.events] == [
        "OrderConfirmed",
        "OrderShipped",
        "OrderDelivered",
    ]
