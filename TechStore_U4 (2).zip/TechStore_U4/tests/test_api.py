
import pytest
from fastapi.testclient import TestClient

from app.api import app, orders

client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_orders():
    """Restablece los pedidos antes de cada prueba."""
    from cargar_csv import load_fixture

    orders.clear()
    orders.update(load_fixture())


def test_api_inicio():
    response = client.get("/")

    assert response.status_code == 200
    assert response.json()["message"] == "TechStore API funcionando"


def test_listar_pedidos():
    response = client.get("/orders")

    assert response.status_code == 200
    assert len(response.json()) == 16


def test_consultar_pedido_existente():
    response = client.get("/orders/O001")

    assert response.status_code == 200
    assert response.json()["id"] == "O001"
    assert response.json()["status"] == "DRAFT"


def test_consultar_pedido_inexistente():
    response = client.get("/orders/NO_EXISTE")

    assert response.status_code == 404


def test_confirmar_pedido():
    response = client.post("/orders/O013/confirm")

    assert response.status_code == 200
    assert response.json()["status"] == "CONFIRMED"
    assert response.json()["events"][0]["name"] == "OrderConfirmed"


def test_no_confirmar_dos_veces():
    primera = client.post("/orders/O013/confirm")
    segunda = client.post("/orders/O013/confirm")

    assert primera.status_code == 200
    assert segunda.status_code == 409

    pedido = client.get("/orders/O013").json()
    assert pedido["status"] == "CONFIRMED"
    assert len(pedido["events"]) == 1


def test_enviar_pedido_confirmado():
    client.post("/orders/O013/confirm")

    response = client.post(
        "/orders/O013/ship",
        json={"tracking_number": "GUIA-013"},
    )

    assert response.status_code == 200
    assert response.json()["status"] == "SHIPPED"
    assert [e["name"] for e in response.json()["events"]] == [
        "OrderConfirmed",
        "OrderShipped",
    ]


def test_no_enviar_sin_confirmar():
    response = client.post(
        "/orders/O013/ship",
        json={"tracking_number": "GUIA-013"},
    )

    assert response.status_code == 409
    pedido = client.get("/orders/O013").json()
    assert pedido["status"] == "DRAFT"
    assert pedido["events"] == []


def test_enviar_sin_guia():
    client.post("/orders/O013/confirm")

    response = client.post(
        "/orders/O013/ship",
        json={"tracking_number": ""},
    )

    assert response.status_code == 422
    pedido = client.get("/orders/O013").json()
    assert pedido["status"] == "CONFIRMED"
    assert len(pedido["events"]) == 1


def test_cancelar_pedido_confirmado():
    client.post("/orders/O012/confirm")

    response = client.post(
        "/orders/O012/cancel",
        json={"reason": "Prueba automatizada"},
    )

    assert response.status_code == 200
    assert response.json()["status"] == "CANCELLED"
    assert [e["name"] for e in response.json()["events"]] == [
        "OrderConfirmed",
        "OrderCancelled",
    ]


def test_entregar_pedido_enviado():
    client.post("/orders/O016/confirm")
    client.post(
        "/orders/O016/ship",
        json={"tracking_number": "GUIA-016"},
    )

    response = client.post("/orders/O016/deliver")

    assert response.status_code == 200
    assert response.json()["status"] == "DELIVERED"


def test_devolver_pedido_enviado():
    client.post("/orders/O015/confirm")
    client.post(
        "/orders/O015/ship",
        json={"tracking_number": "GUIA-015"},
    )

    response = client.post("/orders/O015/return")

    assert response.status_code == 200
    assert response.json()["status"] == "RETURNED"
    assert [e["name"] for e in response.json()["events"]] == [
        "OrderConfirmed",
        "OrderShipped",
        "OrderReturned",
    ]


def test_no_devolver_pedido_draft():
    response = client.post("/orders/O015/return")

    assert response.status_code == 409
    pedido = client.get("/orders/O015").json()
    assert pedido["status"] == "DRAFT"
    assert pedido["events"] == []
