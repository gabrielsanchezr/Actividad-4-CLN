# TechStore U4 — Actividad 4 de Componentes de Lógica

## Descripción

TechStore U4 es un proyecto académico en Python que modela pedidos de una tienda y aplica reglas de negocio relacionadas con clientes, artículos, descuentos y transiciones de estado. Incluye una API REST desarrollada con FastAPI y pruebas automatizadas con pytest.

Los datos de prueba se cargan desde archivos CSV. El repositorio de pedidos de la API se mantiene en memoria; por lo tanto, los cambios realizados a través de la API no persisten cuando se reinicia el servidor.

## Requisitos

- Python 3.11 o superior.
- pip.
- Las dependencias listadas en `requirements.txt`.

## Estructura del proyecto

```text
TechStore_U4/
├── app/
│   ├── __init__.py
│   ├── api.py
│   ├── domain.py
│   └── specifications.py
├── datos/
│   ├── clientes.csv
│   ├── detalle_pedidos.csv
│   ├── escenarios.csv
│   ├── pedidos.csv
│   └── productos.csv
├── tests/
│   ├── test_api.py
│   ├── test_domain.py
│   └── test_escenarios.py
├── cargar_csv.py
├── probar_cancelacion_devolucion.py
├── probar_descuentos.py
├── probar_envio.py
├── probar_estados.py
├── README.md
└── requirements.txt
```

## Instalación

Abre una terminal en la carpeta raíz del proyecto y ejecuta:

```powershell
py -m venv .venv
```

Activa el entorno virtual en Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

Instala las dependencias:

```powershell
py -m pip install -r requirements.txt
```

Si PowerShell bloquea la activación del entorno virtual, puedes ejecutar los comandos con `py -m pip` sin activarlo, aunque se recomienda usar un entorno virtual.

## Cargar y comprobar los datos

Para mostrar los pedidos cargados desde los CSV:

```powershell
py cargar_csv.py
```

El paquete de datos incluye 12 clientes, 12 productos, 16 pedidos, 21 líneas de detalle y 15 escenarios de evaluación. Todos los pedidos comienzan en estado `DRAFT`.

Para ejecutar los scripts de comprobación manual:

```powershell
py probar_descuentos.py
py probar_estados.py
py probar_envio.py
py probar_cancelacion_devolucion.py
```

## Reglas de negocio implementadas

- Los importes monetarios se representan mediante `Decimal`; `Money` rechaza importes negativos o no finitos.
- Un pedido puede contener como máximo 20 unidades en total, no 20 líneas de artículos.
- El descuento del 10 % se aplica si el cliente es VIP, el total es mayor que $500 MXN, el pedido tiene al menos 4 unidades y no tiene promoción activa.
- El descuento del 5 % se aplica si el total es mayor que $5,000 MXN y no hay promoción activa.
- Si se cumplen ambas reglas de descuento, se prioriza la del 10 %.
- No se puede confirmar un pedido vacío ni un pedido de un cliente inactivo.
- No se puede enviar un pedido sin número de guía.
- Las transiciones inválidas se rechazan y no deben añadir eventos al pedido.
- El stock del catálogo no se utiliza para implementar control de inventario en este laboratorio.

## Estados y transiciones

Los estados disponibles son:

- `DRAFT`: pedido en borrador.
- `CONFIRMED`: pedido confirmado.
- `SHIPPED`: pedido enviado.
- `DELIVERED`: pedido entregado.
- `CANCELLED`: pedido cancelado.
- `RETURNED`: pedido devuelto.

Transiciones implementadas:

- `DRAFT` → `CONFIRMED`, cuando el pedido cumple las condiciones para confirmarse.
- `CONFIRMED` → `SHIPPED`, cuando se proporciona una guía válida.
- `CONFIRMED` → `CANCELLED`, cuando se proporciona un motivo válido de cancelación.
- `SHIPPED` → `DELIVERED`, para registrar la entrega.
- `SHIPPED` → `RETURNED`, para registrar la devolución.

La aplicación registra eventos de dominio como `OrderConfirmed`, `OrderShipped`, `OrderCancelled`, `OrderDelivered` y `OrderReturned`.

## Ejecutar la API

Desde la raíz del proyecto, ejecuta:

```powershell
py -m uvicorn app.api:app --reload
```

La API estará disponible en:

- Inicio: http://127.0.0.1:8000/
- Documentación interactiva Swagger: http://127.0.0.1:8000/docs
- Esquema OpenAPI: http://127.0.0.1:8000/openapi.json

Para detener el servidor, usa `Ctrl+C` en la terminal donde se está ejecutando Uvicorn.

## Endpoints disponibles

| Método | Endpoint | Función |
|---|---|---|
| GET | `/` | Comprueba que la API está funcionando. |
| GET | `/orders` | Lista los pedidos cargados. |
| GET | `/orders/{order_id}` | Consulta un pedido por identificador. |
| POST | `/orders/{order_id}/confirm` | Confirma un pedido. |
| POST | `/orders/{order_id}/ship` | Envía un pedido; requiere `tracking_number`. |
| POST | `/orders/{order_id}/cancel` | Cancela un pedido confirmado; requiere `reason`. |
| POST | `/orders/{order_id}/deliver` | Registra la entrega de un pedido enviado. |
| POST | `/orders/{order_id}/return` | Registra la devolución de un pedido enviado. |

Ejemplo del cuerpo JSON para enviar un pedido:

```json
{
  "tracking_number": "GUIA-013"
}
```

Ejemplo del cuerpo JSON para cancelar un pedido:

```json
{
  "reason": "El cliente solicitó cancelar"
}
```

La API devuelve `404` si el pedido no existe, `409` cuando se intenta una transición no permitida y `422` cuando los datos de entrada o las reglas de negocio no se cumplen.

## Ejecutar las pruebas automatizadas

Ejecutar únicamente las pruebas de dominio:

```powershell
py -m pytest tests/test_domain.py -v
```

Ejecutar los 15 escenarios:

```powershell
py -m pytest tests/test_escenarios.py -v
```

Ejecutar las pruebas de la API:

```powershell
py -m pytest tests/test_api.py -v
```

Ejecutar toda la suite:

```powershell
py -m pytest -v
```

Durante la preparación de esta entrega, la ejecución completa reportó 39 pruebas aprobadas. Para verificar el estado actual en tu equipo, vuelve a ejecutar el último comando y conserva una captura del resumen.

## Limitaciones conocidas

- La API utiliza un repositorio en memoria. Los cambios se pierden al reiniciar el proceso.
- La persistencia con SQLite no está incluida porque no es el objetivo principal de este laboratorio.
- El simulador no implementa control de inventario.
- Las pruebas automatizadas validan los comportamientos cubiertos por los casos escritos; no sustituyen la revisión de los requisitos de entrega ni las evidencias solicitadas por el docente.
