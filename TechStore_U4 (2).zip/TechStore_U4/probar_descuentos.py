
print("INICIO DE LA PRUEBA")

from cargar_csv import load_fixture
from app.specifications import get_discount_rate

orders = load_fixture()
print("Pedidos cargados:", len(orders))

for order_id, order in orders.items():
    rate = get_discount_rate(order)
    print(f"{order_id} | Descuento: {rate * 100}%")

print("FIN DE LA PRUEBA")
